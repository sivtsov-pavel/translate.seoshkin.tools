/**
 * Smooth road through node centers (Catmull-Rom -> cubic Bezier).
 * @param {Array<[number, number]>} pts  node centers [x, y] in map coordinates
 * @returns {string} SVG path "d"
 */
export function roadPath(pts) {
  if (!pts.length) return '';
  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += ` C ${c1[0]} ${c1[1]}, ${c2[0]} ${c2[1]}, ${p2[0]} ${p2[1]}`;
  }
  return d;
}

/** Desktop offset pattern (px from column center); tablet: multiply by ~0.88. */
export const OFFSETS_DESKTOP = [40, 150, 170, 40, -170, -170, 10, 150, 110, -40];

/**
 * Compute node centers for one unit.
 * @param {Array<{status:'done'|'open'|'current'|'locked'|'chest'|'boss'}>} lessons
 * @param {{centerX:number, startY:number, step?:number, afterCurrent?:number, scale?:number}} o
 */
export function layoutNodes(lessons, { centerX, startY, step = 118, afterCurrent = 90, scale = 1 }) {
  let y = startY;
  const curIdx = lessons.findIndex(l => l.status === 'current');
  // shift pattern so the current lesson lands on the left (-170) slot
  const shift = curIdx >= 0 ? (curIdx - 4 + OFFSETS_DESKTOP.length) % OFFSETS_DESKTOP.length : 0;
  return lessons.map((l, i) => {
    if (l.status === 'boss') y += 20;
    const off = OFFSETS_DESKTOP[(i - shift + OFFSETS_DESKTOP.length * 10) % OFFSETS_DESKTOP.length] * scale;
    const p = [centerX + off, y];
    y += step + (l.status === 'current' ? afterCurrent : 0);
    return p;
  });
}
